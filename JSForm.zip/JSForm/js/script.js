//Validate Name JS
function ValidateName(){
    var name = document.getElementById("fullName");
    var nameMsg = document.getElementById("fullNameMsg");
    if(name.value == ""){
        nameMsg.src = "https://img.pngio.com/false-icon-with-png-and-vector-format-for-free-unlimited-download-false-png-512_512.png";
        name.style.color="#ff1b1b";
    } else {
        nameMsg.src = "http://clipart-library.com/images_k/checkmark-icon-transparent/checkmark-icon-transparent-16.png";
        name.style.color="#61df00";
    }
}

//Validate Email JS
function ValidateEmail(){
    var email = document.getElementById("emailId");
    var mailFormat = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
    var emailMsg = document.getElementById("emailIdMsg");
    if(email.value.match(mailFormat)){
        emailMsg.src = "http://clipart-library.com/images_k/checkmark-icon-transparent/checkmark-icon-transparent-16.png";
        email.style.color="#61df00";
    } else {
        emailMsg.src = "https://img.pngio.com/false-icon-with-png-and-vector-format-for-free-unlimited-download-false-png-512_512.png";
        email.style.color="#ff1b1b";
    }
}

//Validate Phone JS
function ValidatePhone(){
    var phone = document.getElementById("phoneNo");
    var phoneFormat = /^\d{10}$/;
    var phoneMsg = document.getElementById("phoneNoMsg");
    if(phone.value.match(phoneFormat)){
        phoneMsg.src = "http://clipart-library.com/images_k/checkmark-icon-transparent/checkmark-icon-transparent-16.png";
        phone.style.color="#61df00";
    } else {
        phoneMsg.src = "https://img.pngio.com/false-icon-with-png-and-vector-format-for-free-unlimited-download-false-png-512_512.png";
        phone.style.color="#ff1b1b";
    }
}

//Validate Only Number JS
function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}

//Validate Checkbox JS
function ValidateCheckbox() {
    var checkBox = document.getElementById("checkTerm");
    var text = document.getElementById("text");
    if (checkBox.checked == true){
      text.style.display = "none";
    } else {
       text.style.display = "block";
    }
}

//Validate Submit Button JS
function btnClick(){
    var name = document.getElementById("fullName");
    var email = document.getElementById("emailId");
    var phone = document.getElementById("phoneNo");
    var checkBox = document.getElementById("checkTerm");
    var radio = document.getElementsByName("gender");
    if(name.value == "" || email.value=="" || phone.value=="" || checkBox.checked == false || (radio[0].checked == false && radio[1].checked==false)){
        alert("Please Fill All Details");
    } else {
        alert("Thank you for filling out your information!!!!");
    }
}